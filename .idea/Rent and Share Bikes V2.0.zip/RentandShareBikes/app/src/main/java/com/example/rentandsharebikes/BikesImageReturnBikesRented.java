package com.example.rentandsharebikes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BikesImageReturnBikesRented extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bikes_image_return_bikes_rented);
    }
}
